import type { ExpoConfig } from '@expo/config-types';
import {
  type ConfigPlugin,
  AndroidConfig,
  IOSConfig,
  createRunOncePlugin,
  withPlugins,
  withInfoPlist,
} from '@expo/config-plugins';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const pkg = require('../../package.json');

type Options = {
  iosUrlScheme: string;
};

function validateOptions(options: Options) {
  const messagePrefix = `@metamask/react-native-acm config plugin`;
  if (!options?.iosUrlScheme) {
    throw new Error(
      `${messagePrefix}: Missing \`iosUrlScheme\` in provided options: ${JSON.stringify(options)}`
    );
  }
  if (!options.iosUrlScheme.startsWith('com.googleusercontent.apps.')) {
    throw new Error(
      `${messagePrefix}: \`iosUrlScheme\` must start with "com.googleusercontent.apps.": ${JSON.stringify(options)}`
    );
  }
}

export const withGoogleUrlScheme: ConfigPlugin<Options> = (config, options) => {
  return withInfoPlist(config, (cfg) => {
    const scheme = options.iosUrlScheme;
    const infoPlist = cfg.modResults;
    if (!IOSConfig.Scheme.hasScheme(scheme, infoPlist)) {
      cfg.modResults = IOSConfig.Scheme.appendScheme(scheme, infoPlist);
    }
    return cfg;
  });
};

/**
 * Non-Firebase mode: validates the iosUrlScheme and registers it
 * in Info.plist so the Google Sign-In OAuth redirect works.
 */
const withGoogleSignInWithoutFirebase: ConfigPlugin<Options> = (
  config: ExpoConfig,
  options
) => {
  validateOptions(options);
  return withPlugins(config, [
    // iOS
    (cfg) => withGoogleUrlScheme(cfg, options),
  ]);
};

/**
 * Firebase mode: uses Expo's built-in helpers to wire up Google Services
 * on Android (classpath, plugin, google-services.json) and iOS
 * (Google config, GoogleService-Info.plist).
 */
const withGoogleSignIn: ConfigPlugin = (config: ExpoConfig) => {
  return withPlugins(config, [
    // Android
    AndroidConfig.GoogleServices.withClassPath,
    AndroidConfig.GoogleServices.withApplyPlugin,
    AndroidConfig.GoogleServices.withGoogleServicesFile,

    // iOS
    IOSConfig.Google.withGoogle,
    IOSConfig.Google.withGoogleServicesFile,
  ]);
};

const withGoogleSignInRoot: ConfigPlugin<Options | void> = (
  config: ExpoConfig,
  options
) => {
  return options
    ? withGoogleSignInWithoutFirebase(config, options)
    : withGoogleSignIn(config);
};

export default createRunOncePlugin<Options>(
  withGoogleSignInRoot,
  pkg.name,
  pkg.version
);
