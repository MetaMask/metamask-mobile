import { type ConfigPlugin } from '@expo/config-plugins';
type Options = {
    iosUrlScheme: string;
};
export declare const withGoogleUrlScheme: ConfigPlugin<Options>;
declare const _default: ConfigPlugin<Options>;
export default _default;
//# sourceMappingURL=index.d.ts.map