# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [14.8.0]

### Fixed

- fix: serialize URLs used in native download JavaScript ([#79](https://github.com/MetaMask/react-native-webview-mm/pull/79))

### Added

- add `additionalMessageHandlerNames` prop (iOS) to register extra native script message handlers that forward to `onMessage`, including in Apple Pay mode

## [14.7.0]

### Added

- add `additionalMessageHandlerNames` prop (iOS) to register extra native script message handlers that forward to `onMessage`, including in Apple Pay mode

## [14.6.0]

### Added

- add allowFileDownloads and suppressJavaScriptDialogs props

### Fixed

- fix Android In-App Browser Crash
- fix iOS download file.bin alert

## [14.5.0]

### Added

- Enable support for Google Pay (Android)

### Fixed

- Prevent WebView from downloading images, in lieu of just displaying
- Handle missing service worker bug on iOS

## [14.4.0]

### Added

- On iOS add additional detection of embedded iFrames (https://github.com/MetaMask/react-native-webview-mm/pull/67)
- Handle messages only coming from the main frame to prevent spoofing from child iframes (https://github.com/MetaMask/react-native-webview-mm/pull/55)

## [14.3.0]

### Added

- Inject Javascript on iOS to detect all iFrames inside the current page and report them to the React app (https://github.com/MetaMask/react-native-webview-mm/pull/61)
- Inject Javascript on Android to detect all iFrames inside the current page and report them to the React app (https://github.com/MetaMask/react-native-webview-mm/pull/60)

## [14.2.2]

### Fixed

- On iOS on opening of some Dapps there is download file pop up (https://github.com/MetaMask/react-native-webview-mm/pull/63)

## [14.2.1]

### Fixed

- Download file requested when connecting to any Dapp (https://github.com/MetaMask/react-native-webview-mm/pull/58)

## [14.2.0]

### Added

- Implement tapjacking prevention via 500ms delay (https://github.com/MetaMask/react-native-webview-mm/pull/54, https://github.com/MetaMask/react-native-webview-mm/pull/52)

### Fixed

- Fixes to blob downloading on both platforms (https://github.com/MetaMask/react-native-webview-mm/pull/51, https://github.com/MetaMask/react-native-webview-mm/pull/50)
- Fix to regular file downloads on iOS (https://github.com/MetaMask/react-native-webview-mm/pull/53)

## [14.1.0]

### Changed

- bump ws from 6.2.2 to 6.2.3 in the npm_and_yarn group across 1 directory (https://github.com/MetaMask/react-native-webview-mm/pull/35)
- sync with upstream v13.13.5 (https://github.com/MetaMask/react-native-webview-mm/pull/47)

[Unreleased]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.8.0...HEAD
[14.8.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.7.0...v14.8.0
[14.7.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.6.0...v14.7.0
[14.6.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.5.0...v14.6.0
[14.5.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.4.0...v14.5.0
[14.4.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.3.0...v14.4.0
[14.3.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.2.2...v14.3.0
[14.2.2]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.2.1...v14.2.2
[14.2.1]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.2.0...v14.2.1
[14.2.0]: https://github.com/MetaMask/react-native-webview-mm/compare/v14.1.0...v14.2.0
[14.1.0]: https://github.com/MetaMask/react-native-webview-mm/releases/tag/v14.1.0
